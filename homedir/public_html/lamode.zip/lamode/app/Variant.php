<?php

namespace App;


use Illuminate\Database\Eloquent\Model;

class Variant extends Model
{
    //
    protected $fillable = [
        'name', 'description', 'category_id'
    ];

    public function category()
    {
        return $this->belongsTo('App\Category');
    }

    public function stocks(){
        return $this->hasMany('App\Stock');
    }
}
