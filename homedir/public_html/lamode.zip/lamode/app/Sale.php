<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sale extends Model
{
    //

    protected $fillable = [
        'code', 'order_type', 'branch_id', 'customer_id', 'address1', 'address2', 'city', 'zipcode', 'shipment_no',
        'delivery_type', 'payment_type', 'subtotal_amount', 'discount_amount', 'shipping_amount', 'total_amount',
        'order_date', 'user_id', 'products', 'status', 'archived'
    ];


    public function customer()
    {
        return $this->belongsTo('App\Customer');
    }

    public function branch()
    {
        return $this->belongsTo('App\Branch');
    }
}
