<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Stock extends Model
{
    //
    protected $fillable = [
        'product_id', 'branch_id', 'variant_id', 'stock', 'price'
    ];


    public function product()
    {
        return $this->belongsTo('App\Product');
    }

    public function branch()
    {
        return $this->belongsTo('App\Branch');
    }

    public function variant()
    {
        return $this->belongsTo('App\Variant');
    }
}
