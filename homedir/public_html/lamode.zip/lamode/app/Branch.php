<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Branch extends Model
{
    protected $fillable = [
        'name', 'type'
    ];

    public function stocks(){
        return $this->hasMany('App\Stock');
    }

    public function sales(){
        return $this->hasMany('App\Sale');
    }

    public function users(){
        return $this->hasMany('App\User');
    }
    //
}
