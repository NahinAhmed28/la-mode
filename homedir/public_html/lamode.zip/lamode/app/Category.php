<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    //
    protected $fillable = [
        'name', 'description', 'has_variant'
    ];

    public function variants(){
        return $this->hasMany('App\Variant');
    }

    public function products(){
        return $this->hasMany('App\Product');
    }
}
