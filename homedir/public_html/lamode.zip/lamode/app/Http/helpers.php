<?php

if (! function_exists('format_price')) {
    function format_price($price) {
        // ...
        return '৳ '.number_format((float)$price, 2, '.', '');
    }
}


if (! function_exists('isActiveRoute')) {
    function isActiveRoute($route, $output = "active")
    {
        if (Route::currentRouteName() == $route) return $output;
    }
}

if (! function_exists('areActiveRoutes')) {
    function areActiveRoutes(Array $routes, $output = "active")
    {
        foreach ($routes as $route) {
            if (Route::currentRouteName() == $route) return $output;
        }

    }
}


if (! function_exists('areOpenSubs')) {
    function areOpenSubs(Array $routes, $output = "opened has-sub")
    {
        foreach ($routes as $route) {
            if (Route::currentRouteName() == $route) return $output;
        }

    }
}

if (! function_exists('myDateFormat')) {
    function myDateFormat($value)
    {
        return date('D, d M Y', strtotime($value));

    }
}


if (! function_exists('getUserRole')) {
    function getUserRole($user_type)
    {
        if ($user_type == 1)
            return 'Admin';
        elseif ($user_type == 2)
            return 'Staff/Regular';
        else
            return 'Staff/E-Commerce';

    }
}
