<?php

namespace App\Http\Controllers;

use App\Branch;
use App\Category;
use App\Product;
use App\Stock;
use App\Variant;
use Illuminate\Http\Request;
use Image; //Intervention Image
use Illuminate\Support\Facades\Storage; //Laravel Filesystem
use File;

class ProductController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $products = Product::all();
        $branches = Branch::all();
        $variants = Variant::all();
        return view('products.index', compact('products', 'branches', 'variants'));
    }

    public function get_list($status)
    {
        $categories =  Category::all();
        $branches = Branch::all();
        $variants = Variant::all();
        if($status == 'all')
        {
            $products = Product::where('archived', 0)->get();
        }
        elseif ($status == 'archived')
        {
            $products = Product::where('archived', 1)->get();
        }
        else {

            $products = Product::where([
                ['category_id', $status],
                ['archived',  0]
            ])->get();

        }
        return view('products.list', compact('products', 'status', 'categories', 'branches', 'variants'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $categories = Category::all();

        $category_list = array();

        foreach ($categories as $category){
            $category_list[$category->id] = $category->name;
        }

        $branches = Branch::all();
        $variants = Variant::all();

        return view('products.create', compact('category_list','branches', 'variants'));
    }

    public function stock_table($category_id)
    {

        $category = Category::find($category_id);
        $branches = Branch::all();
        $variants = Variant::all();

        return view('products.stock_table', compact('category', 'branches', 'variants'))->render();

    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        request()->validate([
            'name' => 'required',
            'sku' => 'required',
            'category_id' => 'required',
        ]);

        $filenametostore = '';
        if ($request->hasFile('product_image')) {

            $file = $request->file('product_image');


            //get filename with extension
            $filenamewithextension = $file->getClientOriginalName();

            //get filename without extension
            $filename = pathinfo($filenamewithextension, PATHINFO_FILENAME);

            //get file extension
            $extension = $file->getClientOriginalExtension();

            //filename to store
            $filenametostore = $filename . '_' . uniqid() . '.' . $extension;


            $file->move('uploads/product_images/', $filenametostore);
            File::copy('uploads/product_images/'. $filenametostore , 'uploads/product_images/thumbs/'. $filenametostore);
            $thumbnailpath = 'uploads/product_images/thumbs/' . $filenametostore;
            $img = Image::make($thumbnailpath)->resize(300, 150, function ($constraint) {
                $constraint->aspectRatio();
            });
            $img->save($thumbnailpath);

        }

        $product = Product::create(array_merge($request->all(), ['image' => $filenametostore]));
        $branches = Branch::all();
        $category = $product->category;

        if ($category->has_variant == 1)
        {
            if($request->has('variant_id'))
            {
                foreach($request->variant_id as $key => $variant_id)
                {

                    foreach($branches  as $branch)
                    {
                        $stock = Stock::create([
                            'product_id' => $product->id,
                            'variant_id' => $variant_id,
                            'branch_id' => $branch->id,
                            'stock' => $request->input('stock_'.$branch->id.'.'.$key),
                        ]);
                    }

                }
            }
        }
        else
        {
            if($request->has('stock'))
            {
                foreach($branches  as $key =>$branch)
                {
                    $stock = Stock::create([
                        'product_id' => $product->id,
                        'variant_id' => 0,
                        'branch_id' => $branch->id,
                        'stock' => $request->stock[$key],
                    ]);
                }
            }

        }

        return redirect()->route('products.get_list', $category->id)
            ->with('success','Product created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        //
        $branches = Branch::all();
        $variants = Variant::all();

        return view('products.details', compact('branches', 'variants', 'product'))->render();
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        //
        $categories = Category::all();

        $category_list = array();

        foreach ($categories as $category){
            $category_list[$category->id] = $category->name;
        }

        $branches = Branch::all();
        $variants = Variant::all();

        return view('products.edit', compact('category_list','branches', 'variants', 'product'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        //
        request()->validate([
            'name' => 'required',
            'sku' => 'required'
        ]);

        $filenametostore = $product->image;
        if ($request->hasFile('product_image')) {

            $file = $request->file('product_image');


            //get filename with extension
            $filenamewithextension = $file->getClientOriginalName();

            //get filename without extension
            $filename = pathinfo($filenamewithextension, PATHINFO_FILENAME);

            //get file extension
            $extension = $file->getClientOriginalExtension();

            //filename to store
            $filenametostore = $filename . '_' . uniqid() . '.' . $extension;

            $file->move('uploads/product_images/', $filenametostore);
            File::copy('uploads/product_images/'. $filenametostore , 'uploads/product_images/thumbs/'. $filenametostore);
//            Storage::put('public/product_images/' . $filenametostore, fopen($file, 'r+'));
//            Storage::put('public/product_images/thumbs/' . $filenametostore, fopen($file, 'r+'));
            $thumbnailpath = public_path('uploads/product_images/thumbs/' . $filenametostore);
            $img = Image::make($thumbnailpath)->resize(300, 150, function ($constraint) {
                $constraint->aspectRatio();
            });
            $img->save($thumbnailpath);

        }

        $product->update(array_merge($request->all(), ['image' => $filenametostore]));

        $branches = Branch::all();
        $category = $product->category;

        if ($category->has_variant == 1)
        {
            if($request->has('variant_id'))
            {
                foreach($request->variant_id as $key => $variant_id)
                {

                    foreach($branches  as $branch)
                    {
                        $stocks = Stock::where([
                            ['product_id', $product->id],
                            ['variant_id',  $variant_id],
                            ['branch_id', $branch->id]])->get();

                        if ($stocks->count() > 0) {
                            // do something
                            $stocks->first()->update(['stock' => $request->input('stock_'.$branch->id.'.'.$key)]);
                        }
                        else {
                            $stock = Stock::create([
                                'product_id' => $product->id,
                                'variant_id' => $variant_id,
                                'branch_id' => $branch->id,
                                'stock' => $request->input('stock_'.$branch->id.'.'.$key),
                            ]);
                        }

                    }

                }
            }
        }
        else
        {
            if($request->has('stock'))
            {
                foreach($branches  as $key =>$branch)
                {
                    $stocks = Stock::where([
                        ['product_id', $product->id],
                        ['branch_id', $branch->id]])->get();

                    if ($stocks->count() > 0) {
                        // do something
                        $stocks->first()->update(['stock' => $request->stock[$key]]);
                    }
                    else
                        {
                        $stock = Stock::create([
                            'product_id' => $product->id,
                            'variant_id' => 0,
                            'branch_id' => $branch->id,
                            'stock' => $request->stock[$key],
                        ]);

                    }


                }
            }

        }


        return redirect()->route('products.get_list', $category->id)
            ->with('success','Product updated successfully');
    }

    public function transfer_stock(Product $product)
    {
        $branches = Branch::where('type', 0)->get();
        $variants = Variant::all();

        return view('products.transfer_stock', compact('branches', 'variants', 'product'));
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function delete($id)
    {
        Product::destroy($id);
        return redirect()->route('products.get_list', 'all')
            ->with('success','Product deleted successfully');
    }


    public function archive($id)
    {
        $product = Product::find($id);
        $product->update(['archived' => 1]);
        //dd($product->archived);
        return redirect()->route('products.get_list', 'archived')
            ->with('success','Product Archived successfully');
    }
}
