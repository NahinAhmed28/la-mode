<?php

namespace App\Http\Controllers;

use App\Branch;
use App\Customer;
use App\Product;
use App\Sale;
use App\Stock;
use App\Variant;
use Illuminate\Http\Request;

class SalesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $sales = Sale::where('archived', 0)->get();
        return view('sales.index', compact('sales'));

    }

    public function get_list($status)
    {
        if($status == 'all')
        {
            $sales = Sale::where('archived', 0)->get();
        }
        return view('sales.list', compact('sales', 'status'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $branches = Branch::where('type', 0)->get();

        $branch_list = array();

        foreach ($branches as $branch){
            $branch_list[$branch->id] = $branch->name;
        }

        return view('sales.create', compact('branch_list'));
    }

    public function customer_add()
    {

        $customers = Customer::all();

        return view('sales.customer_add', compact('customers'))->render();
    }

    public function customer_create()
    {

//        $customers = Customer::all();

        return view('sales.customer_create')->render();
    }

    public function customer_store(Request $request)
    {
        $customer = Customer::create($request->all());
        $val = array( 'customer_id' => $customer->id, 'name' => $customer->name, 'phone' => $customer->phone, 'address1' => $customer->address1,
            'email' => $customer->email, 'address2' => $customer->address2, 'city' => $customer->city, 'zipcode' => $customer->zipcode);

        return response()->json($val);
    }


    public function customer($customer_id){

        $customer = Customer::find($customer_id);


        $val = array( 'customer_id' => $customer->id, 'name' => $customer->name, 'phone' => $customer->phone, 'address1' => $customer->address1,
            'email' => $customer->email, 'address2' => $customer->address2, 'city' => $customer->city, 'zipcode' => $customer->zipcode);

        return response()->json($val);
    }

    public function get_products(){
        $products = Product::where('archived', 0)->get();
        $variants =  Variant::all();

        $product_list = array();

        foreach ($products as $product){
            $product_list[$product->id] = $product->name;
        }

        $variant_list = array();

        foreach ($variants as $variant){
            $variant_list[$variant->id] = $variant->name;
        }

        return view('sales.product_row', compact('product_list', 'variant_list'))->render();
    }

    public function get_product_detail(Request $request)
    {

        $product = Product::find($request->product_id);
        $stock = Stock::where([
            ['product_id', $product->id],
            ['variant_id',  $request->variant_id],
            ['branch_id', $request->branch_id]])->get()->first()->stock;

        $val = array( 'price' => $product->price, 'stock' => $stock);

        return response()->json($val);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $order_date = strtotime($request->order_date);
        $request->merge(array('order_date' => $order_date));

        $products = array();
        if($request->has('product_id'))
        {
            foreach($request->product_id as $key => $product_id)
            {
                $product = array();
                $product['id'] = $product_id;
                $product['variant_id'] = $request->variant_id[$key];
                $product['qty'] = $request->qty[$key];
                $product['discount'] = $request->discount[$key];
                $product['discount_amount'] = $request->discount_amount_product[$key];
                $product['total_amount'] = $request->total_amount_product[$key];

                array_push($products,$product);
                //dd($products);
            }

        }

        Sale::create(array_merge($request->all(), ['products' => json_encode($products)]));
        return redirect()->route('sales.index')
            ->with('success','Sale Order created successfully');


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Sale $sale)
    {
        //
        return view('sales.details', compact('sale'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
