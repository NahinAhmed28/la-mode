<?php

namespace App\Http\Controllers;

use App\Category;
use App\Variant;
use Illuminate\Http\Request;

class VariantController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $variants = Variant::all();
        return view('variants.index', compact('variants'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $categories = Category::all();

        $category_list = array();

        foreach ($categories as $category){
            $category_list[$category->id] = $category->name;
        }
        return view('variants.create', compact('category_list'))->render();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        request()->validate([
            'name' => 'required',
            'category_id' => 'required',
        ]);



        Variant::create($request->all());
        return redirect()->route('variants.index')
            ->with('success','Variant created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Variant $variant)
    {
        //
        $categories = Category::all();

        $category_list = array();

        foreach ($categories as $category){
            $category_list[$category->id] = $category->name;
        }

        return view('variants.edit', compact('variant', 'category_list'))->render();
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Variant $variant)
    {
        //
        request()->validate([
            'name' => 'required',
            'category_id' => 'required',
        ]);

        $variant->update($request->all());
        return redirect()->route('variants.index')
            ->with('success','Variant updated successfully');


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function delete($id)
    {
        Variant::destroy($id);
        return redirect()->route('variants.index')
            ->with('success','Variant deleted successfully');
    }
}
