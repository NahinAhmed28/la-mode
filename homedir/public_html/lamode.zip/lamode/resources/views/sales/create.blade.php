@extends('layouts.master')
@section('content')
    <h2>Add Product</h2>
    <br />
    <ol class="breadcrumb bc-3">

        <li>
            <a href="">
                <i class="entypo-home"></i>
                Dashboard
            </a>
        </li>

        <li>
            <a href="">
                Sales Order
            </a>
        </li>

        <li class="active">
            <strong>Add New Order</strong>
        </li>

    </ol>
    @if (count($errors) > 0)
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    {!! Form::open(array('route' => 'sales.store','method'=>'POST', 'id'=>'order-form', 'class'=> 'form-horizontal form-groups-bordered', 'enctype' => "multipart/form-data")) !!}
    <div class="row">

        <div class="col-md-12">
            <div class="panel panel-default" data-collapsed="0">
                <div class="panel-heading">
                    <div class="panel-title">
                        <i class="entypo-user"></i> &nbsp;Customer Information
                    </div>
                </div>
                <div class="panel-body">

                    <div class="col-sm-5">

                        <div class="form-group">
                            <label class="col-sm-3 control-label">Order Code</label>
                            <div class="col-sm-8">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="entypo-code"></i></span>
                                    {!! Form::text('code', substr(md5(rand(0, 1000000)), 0, 7), array( 'id' => 'order_code','class' => 'form-control')) !!}
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-3 control-label">&nbsp;</label>
                            <div class="col-sm-8">
                                <a href="#" onclick="showAjaxModal('{{ route('sales.customer_create') }}');"
                                   class="btn btn-info btn-sm btn-icon icon-left">
                                    New Customer
                                    <i class="entypo-plus"></i>
                                </a>

                                <a href="#" onclick="showAjaxModal('{{ route('sales.customer_add') }}');"
                                   class="btn btn-green btn-sm btn-icon icon-left">
                                    Existing Customer
                                    <i class="entypo-paper-plane"></i>
                                </a>
                            </div>
                            {{ Form::hidden('customer_id',  null, array('id' => 'customer_id', 'required' => 'required')) }}
                        </div>

                        {{ Form::hidden('user_id',  Auth::user()->id, array('required' => 'required')) }}

                        <div class="form-group">
                            <label class="col-sm-3 control-label">Name</label>
                            <div class="col-sm-8">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="entypo-code"></i></span>
                                    {!! Form::text('customer_name', null, array('id' => 'customer_name', 'class' => 'form-control', 'disabled' => 'disabled')) !!}
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-3 control-label">Phone</label>
                            <div class="col-sm-8">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="entypo-code"></i></span>
                                    {!! Form::text('customer_phone', null, array('id' => 'customer_phone', 'class' => 'form-control', 'disabled' => 'disabled')) !!}
                                </div>
                            </div>
                        </div>

                        @php
                            $val= [
                                'regular' => 'Regular',
                                'e-commerce' => 'E-Commerce'];
                        @endphp

                        <div class="form-group">
                            <label class="col-sm-3 control-label">Order Type</label>
                            <div class="col-sm-8">
                                {!! Form::select('order_type', $val, null, array('id' => 'order_type', 'class' => 'form-control')) !!}
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-3 control-label">Branch</label>
                            <div class="col-sm-8">
                                {!! Form::select('branch_id', $branch_list, null, array('id' => 'branch_id', 'class' => 'form-control')) !!}
                            </div>
                        </div>

                        @php
                            $val= [
                                'Cash' => 'Cash',
                                'Cash On Delivery' => 'Cash On Delivery',
                                'bKash' => 'bKash',
                                'POS' => 'POS',
                                'Credit Card' => 'Credit Card'
                                ];
                        @endphp
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Payment Type</label>
                            <div class="col-sm-8">
                                {!! Form::select('payment_type', $val, null, array('class' => 'form-control')) !!}                                    </div>
                        </div>
                        <div id="shipment-type-holder">
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Shipment No</label>
                                <div class="col-sm-8">
                                    {!! Form::text('shipment_no', null, array('placeholder' => 'Shipment No','class' => 'form-control')) !!}

                                </div>
                            </div>

                            @php
                                $val= [
                                    'Aramax' => 'Aramax',
                                    'Edision' => 'Edision',
                                    'Sundarban' => 'Sundarban'
                                    ];
                            @endphp
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Delivery Type</label>
                                <div class="col-sm-8">
                                    {!! Form::select('delivery_type', $val, null, array('class' => 'form-control')) !!}                                    </div>
                            </div>
                        </div>

                    </div>

                    <div class="col-sm-7">

                        <div class="form-group">
                            <label class="col-sm-4 control-label">Address1</label>
                            <div class="col-sm-7">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <a href="#"><i class="entypo-calendar"></i></a>
                                    </div>
                                    {!! Form::text('address1', null, array('id' => 'address1','placeholder' => 'Address Line 1','class' => 'form-control')) !!}
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-4 control-label">Address2</label>
                            <div class="col-sm-7">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <a href="#"><i class="entypo-calendar"></i></a>
                                    </div>
                                    {!! Form::text('address2', null, array( 'id' => 'address2', 'placeholder' => 'Address Line 2','class' => 'form-control')) !!}
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-4 control-label">City</label>
                            <div class="col-sm-7">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <a href="#"><i class="entypo-calendar"></i></a>
                                    </div>
                                    {!! Form::text('city', null, array('id' => 'city','placeholder' => 'City','class' => 'form-control')) !!}
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-4 control-label">Zip Code</label>
                            <div class="col-sm-7">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <a href="#"><i class="entypo-calendar"></i></a>
                                    </div>
                                    {!! Form::text('zipcode', null, array('id' => 'zipcode','placeholder' => 'Zip Code','class' => 'form-control')) !!}
                                </div>
                            </div>
                        </div>


                        <div class="form-group">
                            <label class="col-sm-4 control-label">Date</label>
                            <div class="col-sm-7">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <a href="#"><i class="entypo-calendar"></i></a>
                                    </div>
                                    {!! Form::text('order_date', date('D, d M Y'), array('data-format' => 'D, dd MM yyyy','placeholder' => 'Order Date','class' => 'form-control datepicker')) !!}

                                </div>
                            </div>
                        </div>

                        @php
                            $val= [
                                0 => 'Pending',
                                1 => 'Confirmed',
                                2 => 'Delivered'
                                ];
                        @endphp
                        <div class="form-group">
                            <label class="col-sm-4 control-label">Status</label>
                            <div class="col-sm-7">
                                {!! Form::select('status', $val, null, array('class' => 'form-control')) !!}
                            </div>
                        </div>


                    </div>

                </div>
            </div>
        </div>

    </div>

    <div class="row">

        <div class="col-md-12">

            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="panel-title">
                        <i class="entypo-basket"></i> &nbsp;Products
                    </div>
                </div>

                <div class="panel-body">



                    <table id="product-table" class="table table-bordered responsive">
                        <thead>
                        <tr>
                            <th width="23%">Product Name</th>
                            <th width="16%">Variant</th>
                            <th>Stock</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Discount(%)</th>
                            <th>Subtotal</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>


                        </tbody>
                    </table>
                    <div class="row">
                        <div class="col-sm-12">

                        </div>
                    </div>


                    <div id="sales_order_entry_append"></div>

                    <div class="col-sm-12" style="margin-top: 15px;">
                        <button type="button" id="add_entry_button" class="btn btn-info btn-icon icon-left btn-sm"
                                onclick="append_sales_order_entry()">
                            Add Product
                            <i class="entypo-plus"></i>
                        </button>
                    </div>

                </div>
                <br>
                <div class="well well-sm" style="text-align: right; margin-bottom: 0px">
                    <strong>Sub Total : </strong>
                    <span id="subtotal-amount">0.00</span>
                    {{ Form::hidden('subtotal_amount',  0, array('id' => 'subtotal_amount')) }}
                </div>
                <div class="well well-sm" style="text-align: right; margin-bottom: 0px">
                    <strong>Discount : </strong>
                    <span id="discount-amount">0.00</span>
                    {{ Form::hidden('discount_amount',  0, array('id' => 'discount_amount')) }}
                </div>
                <div class="well well-sm" style="text-align: right; margin-bottom: 0px">
                    <strong>Shipping & Handling : </strong>
                    <span id="shipping-amount">0.00</span>
                    {{ Form::hidden('shipping_amount',  0, array('id' => 'shipping_amount')) }}
                </div>
                <div class="well well-sm" style="text-align: right;">
                    <strong>Total : </strong>
                    <span id="total-amount">0.00</span>
                    {{ Form::hidden('total_amount',  0, array('id' => 'total_amount')) }}
                </div>
            </div>

        </div>

    </div>
    <center>

        <button type="button" id="submit_button" class="btn btn-green btn-icon icon-left" onclick="show_alert()">
            Create Order
            <i class="entypo-check"></i>
        </button>

    </center>

    {!! Form::close() !!}

    <script type="text/javascript">

        $.ajaxSetup({

            headers: {

                'X-CSRF-TOKEN': '{{ csrf_token() }}'

            }

        });

        function append_sales_order_entry() {

            $.ajax({

                type:'GET',

                url:'{{ route('sales.get_products') }}',

                success:function(response){

                    jQuery('#product-table tbody').append(response);
                     init_scripts();
                    // calculate_subtotal();
                }

            });

        }

        function init_scripts() {
            $('select.select-2').select2();

            $(".delete-row").click(function(){
                //console.log('here');
                $(this).closest('tr').remove();
                calculate_subtotal();
            });

            $('.product_select').on('change', function () {

                var product_id = $(this).val();
                var table_tr = $(this).closest('tr');
                var variant_id = $(table_tr).find('.variant_select').val();
                var branch_id = $('#branch_id').val();
                $(table_tr).find('.product_id').val(product_id);

                populate_product_row(product_id, variant_id, branch_id, table_tr);


            });


            $('.variant_select').on('change', function () {

                var variant_id = $(this).val();
                var table_tr = $(this).closest('tr');
                var product_id = $(table_tr).find('.product_id').val();
                var branch_id = $('#branch_id').val();

                populate_product_row(product_id, variant_id, branch_id, table_tr);

            });

            $('.qty-product').bind('keyup mouseup', function () {
                var qty= $(this).val();
                var table_tr = $(this).closest('tr');
                var price = $(table_tr).find('.price').val();
                var discount_per = $(table_tr).find('.discount-product').val();

                 calculate_sub_total_product_row(price, qty, discount_per, table_tr);

            });

            $('.discount-product').bind('keyup mouseup', function () {
                var discount_per= $(this).val();
                var table_tr = $(this).closest('tr');
                var price = $(table_tr).find('.price').val();
                var qty = $(table_tr).find('.qty-product').val();

                calculate_sub_total_product_row(price, qty, discount_per, table_tr);

            });


        }

        function calculate_sub_total_product_row(unit_price, qty, discount_per, table_row) {

            var total_amount = parseInt(qty) * parseFloat(unit_price);
            $(table_row).find('.total-product').val(total_amount);
            var discount =  total_amount * (parseFloat(discount_per)/100);
            $(table_row).find('.discount-amount').val(discount);
            var sub_total = total_amount - discount;
            $(table_row).find('.subtotal-product').val(sub_total.toFixed(2));
             calculate_subtotal();

        }

        function calculate_subtotal() {
            console.log('here');
            var subtotal = 0;

            $('.total-product').each(function(){
                subtotal = subtotal + parseFloat($(this).val());

            });


            $('#subtotal-amount').html(subtotal.toFixed(2));
            $('#subtotal_amount').val(subtotal.toFixed(2));
            var total_discount = 0;

            $('.discount-amount').each(function(){
                total_discount = total_discount + parseFloat($(this).val());
            });

            $('#discount-amount').html(total_discount.toFixed(2));
            $('#discount_amount').val(total_discount.toFixed(2));

            var shipping = 0;

            $('#shipping-amount').html(shipping.toFixed(2));
            $('#shipping_amount').val(shipping.toFixed(2));

            var grand_total = subtotal - total_discount + shipping;

            $('#total-amount').html(grand_total.toFixed(2));
            $('#total_amount').val(grand_total.toFixed(2));


        }

        function populate_product_row(product_id, variant_id, branch_id, table_row) {
            var url = '{{ route("sales.get_product_detail") }}';

            if(product_id != null && variant_id != null && branch_id != null)
            {
                $.ajax({

                    type:'POST',

                    url: url,

                    data:{product_id: product_id, variant_id: variant_id, branch_id: branch_id},

                    success:function(response){

                        $(table_row).find('.stock').val(response.stock);
                        $(table_row).find('.price').val(response.price);
                        $(table_row).find('.total-product').val(response.price);
                        $(table_row).find('.subtotal-product').val(response.price);
                        calculate_subtotal();

                    }

                });
            }
        }

        $(function() {
            $('#shipment-type-holder').hide();

            $('select.select-2').select2();
            append_sales_order_entry();


        });

        $('#order_type').on('change', function() {
            var order_type = $('#order_type').val();

            if(order_type != 'regular')
            {
                $('#shipment-type-holder').show();
            }
            else {
                $('#shipment-type-holder').hide();
            }

        });

        function show_alert()
        {
            if($('#order_code').val() == '' || $('#customer_id').val() == '')
                toastr.error('Please insert Order Code and Customer');
            else
                $('#order-form').submit();
        }
    </script>
@endsection