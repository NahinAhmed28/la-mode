<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary" data-collapsed="0">
            <div class="panel-heading">
                <div class="panel-title" >
                    <i class="entypo-plus-circled"></i>
                </div>
            </div>
            <div class="panel-body with-table">

                <table class="table table-bordered datatable" id="table-3" style="vertical-align: middle">
                    <thead>
                    <tr class="replace-inputs">
                        <th width="3%">#</th>
                        <th>Name</th>
                        <th>Phone</th>

                        <th>Email</th>
                        <th>Address</th>
                        <th>Options</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($customers as $key => $customer)
                        <tr>
                            <td>{{ $key+1 }}</td>
                            <td>
                                {{ $customer->name }}
                            </td>
                            <td>
                                {{ $customer->phone }}
                            </td>

                            <td>{{ $customer->email }}</td>
                            <td>
                                {{ $customer->address1.' '.$customer->address2.' '.$customer->city }}
                            </td>
                            <td>
                                <a href="#" onclick="import_customer('{{ $customer->id }}')"
                                   class="btn btn-green btn-sm btn-icon icon-left">
                                    Import
                                    <i class="entypo-paper-plane"></i>
                                </a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>

            </div>

        </div>
    </div>
</div>

<script type="text/javascript">

    function import_customer(customer_id) {

        var customer_id = parseInt(customer_id);
        var url = '{{ route("sales.customer", ":customer_id") }}';
        url = url.replace(':customer_id', customer_id);

        $.ajax({

            type:'GET',

            url: url,


            success:function(response){

                window.parent.jQuery('#customer_id').val(response.customer_id);
                window.parent.jQuery('#customer_name').val(response.name);
                window.parent.jQuery('#customer_phone').val(response.phone);
                window.parent.jQuery('#address1').val(response.address1);
                window.parent.jQuery('#address2').val(response.address2);
                window.parent.jQuery('#city').val(response.city);
                window.parent.jQuery('#zipcode').val(response.zipcode);



                $('#modal_ajax').modal('toggle');


            }

        });
    }

    jQuery( document ).ready( function( $ ) {
        var $table3 = jQuery("#table-3");

        var table3 = $table3.DataTable( {
            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
        } );

        // Initalize Select Dropdown after DataTables is created
        $table3.closest( '.dataTables_wrapper' ).find( 'select' ).select2( {
            minimumResultsForSearch: -1
        });


    } );

</script>