@extends('layouts.master')
@section('content')
    <div class="row">
        <div class="col-md-9">
            <a href=""
               class="btn btn-{{ $status == 'all'? 'primary' : 'default' }}  btn-sm">
                <i class="entypo-folder"></i> &nbsp;All
            </a>
            <a href=""
               class="btn btn-{{ $status == 'pending'? 'primary' : 'default' }} btn-sm">
                <i class="entypo-bell"></i> &nbsp;Pending
            </a>
            <a href=""
               class="btn btn-{{ $status == 'confirmed'? 'primary' : 'default' }} btn-sm">
                <i class="entypo-thumbs-up"></i> &nbsp;Confirmed
            </a>

            <a href=""
               class="btn btn-{{ $status == 'delivered'? 'primary' : 'default' }} btn-sm">
                <i class="entypo-check"></i> &nbsp;Delivered
            </a>
            <a href=""
               class="btn btn-{{ $status == 'archived'? 'gold' : 'default' }} btn-sm">
                <i class="entypo-archive"></i> &nbsp;Archived
            </a>
            <a href=""
               class="btn btn-{{ $status == 'cancelled'? 'danger' : 'default' }} btn-sm">
                <i class="entypo-cancel-circled"></i> &nbsp;Cancelled Orders
            </a>
        </div>

        <a href="{{ route('sales.create') }}"
           class="btn btn-info btn-icon btn-sm icon-left pull-right" style="margin-right: 16px;">
            Add New Order
            <i class="entypo-plus"></i>
        </a>
    </div>
    <br/>

    <div class="row">

        <div class="col-md-12">

            <div class="panel panel-primary">
                <div class="panel-heading">
                    <div class="panel-title">
                        <strong>
                            Order List
                        </strong>
                    </div>
                </div>

                <div class="panel-body with-table">

                    <table class="table table-bordered datatable" id="table-3">
                        <thead>
                        <tr class="replace-inputs">
                            <th width="6%;">Code</th>
                            <th>Customer</th>
                            <th>Branch</th>
                            <th>Order Type</th>
                            <th>Status</th>
                            <th>Total</th>
                            <th>Order Date</th>
                            <th>Options</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($sales as $key => $sale)
                        <tr>
                            <td>
                                <strong>
                                    <a href="" style="color: #949494;">
                                        {{ $sale->code }}
                                    </a>
                                </strong>
                            </td>
                            <td>{{ $sale->customer->name }}</td>
                            <td>{{ $sale->branch->name }}</td>
                            <td>{{ $sale->order_type }}</td>
                            <td>{{ $sale->status }}</td>
                            <td>{{ format_price($sale->total_amount) }}</td>
                            <td>{{ date('D, d M Y' , $sale->order_date) }}</td>
                            <td>
                                <a href="{{ route('sales.show', $sale->id) }}"
                                   class="btn btn-default btn-sm">
                                    <i class="entypo-direction"></i> &nbsp;View
                                </a>

                                <a href="#"
                                   class="btn btn-default btn-sm">
                                    <i class="entypo-trash"></i>
                                </a>
                                <a href="#"
                                   class="btn btn-default btn-sm">
                                    <i class="entypo-archive"></i> &nbsp;Archive
                                </a>

                            </td>
                        </tr>
                        @endforeach
                        </tbody>
                        <tfoot>
                        <tr>
                            <th width="6%;">Code</th>
                            <th>Customer</th>
                            <th>Branch</th>
                            <th>Order Type</th>
                            <th>Status</th>
                            <th>Total</th>
                            <th>Order Date</th>
                            <th>Options</th>
                        </tr>
                        </tfoot>
                    </table>

                </div>
            </div>

        </div>

    </div>

    <script type="text/javascript">

        jQuery( document ).ready( function( $ ) {
            var $table3 = jQuery("#table-3");

            var table3 = $table3.DataTable( {
                "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
            } );

            // Initalize Select Dropdown after DataTables is created
            $table3.closest( '.dataTables_wrapper' ).find( 'select' ).select2( {
                minimumResultsForSearch: -1
            });

            // Setup - add a text input to each footer cell
            $( '#table-3 tfoot th' ).each( function () {
                var title = $('#table-3 thead th').eq( $(this).index() ).text();
                $(this).html( '<input id="foot_' + title +'" type="text" class="form-control" placeholder="Search" />' );
            } );

            // disables search in the option column
            $('#foot_Options').attr("disabled",true);
            $('#foot_Status').attr("disabled",true);
            $('#foot_Total').attr("disabled",true);

            // Apply the search
            table3.columns().every( function () {
                var that = this;

                $( 'input', this.footer() ).on( 'keyup change', function () {
                    if ( that.search() !== this.value ) {
                        that
                            .search( this.value )
                            .draw();
                    }
                } );
            } );
        } );

    </script>
@endsection