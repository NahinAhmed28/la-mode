@extends('layouts.master')
@section('content')
    <h2>Variants</h2>
    <br />
    <ol class="breadcrumb bc-3">

        <li>
            <a href="">
                <i class="entypo-home"></i>
                DashBoard
            </a>
        </li>


        <li class="active">
            <strong>Users</strong>
        </li>

    </ol>

    <a href="{{ route('users.create') }}"
       class="btn btn-info btn-sm btn-icon icon-left">
        Add New User
        <i class="entypo-plus"></i>
    </a>

    <br>

    <br>
    <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered datatable" id="table-3" style="vertical-align: middle">
                <thead>
                <tr>
                    <th width="3%">#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Branch</th>
                    <th width="16%">Options</th>
                </tr>
                </thead>
                <tbody>
                @foreach($users as $key => $user)
                    <tr>
                        <td>{{ $key+1 }}</td>
                        <td>{{ $user->name }}</td>
                        <td>{{ $user->email }}</td>
                        <td>{{ getUserRole($user->user_type) }}</td>
                        <td>{{ $user->user_type == 2 ? $user->branch->name : '' }}</td>
                        <td>
                            @if($user->user_type !=  1)
                            <div class="btn-group">
                                <button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown">
                                    Action <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu dropdown-default" role="menu">
                                    <li>
                                        <a href="{{ route('users.edit', $user->id) }}">
                                            <i class="entypo-pencil"></i> Edit
                                        </a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a href="#" onclick="confirm_modal('{{ route('users.delete', $user->id) }}')">
                                            <i class="entypo-trash"></i> Delete
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            @endif
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>

    <script type="text/javascript">

        jQuery( document ).ready( function( $ ) {
            var $table3 = jQuery("#table-3");

            var table3 = $table3.DataTable( {
                "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
            } );

            // Initalize Select Dropdown after DataTables is created
            $table3.closest( '.dataTables_wrapper' ).find( 'select' ).select2( {
                minimumResultsForSearch: -1
            });



        } );

    </script>
@endsection