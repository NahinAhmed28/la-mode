@extends('layouts.master')
@section('content')
    <h2>Add Product</h2>
    <br />
    <ol class="breadcrumb bc-3">

        <li>
            <a href="">
                <i class="entypo-home"></i>
                Dashboard
            </a>
        </li>

        <li>
            <a href="">
                User
            </a>
        </li>

        <li class="active">
            <strong>Add Product</strong>
        </li>

    </ol>

    @if (count($errors) > 0)
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    {!! Form::model($user, ['class'=> 'form-horizontal', 'enctype' => 'multipart/form-data', 'method' => 'PATCH','route' => ['users.update', $user->id]]) !!}
    @include('users.form')
    {!! Form::close() !!}
@endsection