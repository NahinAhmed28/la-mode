@extends('layouts.master')
@section('content')
    <h2>Add Product</h2>
    <br />
    <ol class="breadcrumb bc-3">

        <li>
            <a href="">
                <i class="entypo-home"></i>
                Dashboard
            </a>
        </li>

        <li>
            <a href="">
                Customer
            </a>
        </li>

        <li class="active">
            <strong>Add Product</strong>
        </li>

    </ol>

    @if (count($errors) > 0)
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    {!! Form::open(array('route' => 'customers.store','method'=>'POST', 'class'=> 'form-horizontal form-groups-bordered', 'enctype' => "multipart/form-data")) !!}

    @include('customers.form')
    {!! Form::close() !!}
    @endsection