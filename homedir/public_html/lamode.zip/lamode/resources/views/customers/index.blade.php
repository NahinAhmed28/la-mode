@extends('layouts.master')
@section('content')
    <h2>Variants</h2>
    <br />
    <ol class="breadcrumb bc-3">

        <li>
            <a href="">
                <i class="entypo-home"></i>
                Customers
            </a>
        </li>


        <li class="active">
            <strong>Products</strong>
        </li>

    </ol>

    <a href="{{ route('products.create') }}"
       class="btn btn-info btn-sm btn-icon icon-left">
        Add New Product
        <i class="entypo-plus"></i>
    </a>

    <br>

    <br>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <div class="panel-title">
                        <strong>
                            Customers
                        </strong>
                    </div>
                </div>

                <div class="panel-body with-table">

                    <table class="table table-bordered datatable" id="table-3" style="vertical-align: middle">
                        <thead>
                        <tr class="replace-inputs">
                            <th width="3%">#</th>
                            <th width="16%">Name</th>
                            <th>Phone</th>

                            <th>Email</th>
                            <th>Address</th>
                            <th>Options</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($customers as $key => $customer)
                            <tr>
                                <td>{{ $key+1 }}</td>
                                <td>
                                    {{ $customer->name }}
                                </td>
                                <td>
                                    {{ $customer->phone }}
                                </td>

                                <td>{{ $customer->email }}</td>
                                <td>
                                    {{ $customer->address1.' '.$customer->address2.' '.$customer->city }}
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown">
                                            Action <span class="caret"></span>
                                        </button>
                                        <ul class="dropdown-menu dropdown-default" role="menu">
                                            <li>
                                                <a href="{{ route('customers.edit', $customer->id) }}">
                                                    <i class="entypo-pencil"></i> Edit
                                                </a>
                                            </li>


                                            <li class="divider"></li>
                                            <li>
                                                <a href="#" onclick="confirm_modal('{{ route('customers.delete', $customer->id) }}')">
                                                    <i class="entypo-trash"></i> Delete
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>

                </div>
            </div>

        </div>
    </div>

    <script type="text/javascript">

        jQuery( document ).ready( function( $ ) {
            var $table3 = jQuery("#table-3");

            var table3 = $table3.DataTable( {
                "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
            } );

            // Initalize Select Dropdown after DataTables is created
            $table3.closest( '.dataTables_wrapper' ).find( 'select' ).select2( {
                minimumResultsForSearch: -1
            });



        } );

    </script>
@endsection