<!DOCTYPE html>
<html lang="en">


<title>LA Mode</title>
@include('partials.metas')
@include('partials.stylesheets')
@include('partials.javascripts')
<!-- INCLUDES THE CSS FILES AND MAIN JQUERY LIBRARY -->

<body class="page-body" data-url="http://neon.dev">

<div class="page-container">

    <!-- INCLUDES THE NAVIGATION MENU FOR USERS -->
    @include('partials.navigation')

    <div class="main-content">

        <!-- INCLUDES THE HEADER -->
        @include('partials.header')


        <!-- INCLUDES THE MAIN BODY FOR EACH PAGE -->
        @yield('content')

    <!-- INCLUDES THE FOOTER -->
        @include('partials.footer')

    </div>

</div>

<!-- INCLUDES ALL JAVASCRIPT FILES -->
@include('partials.modal')
<script type="text/javascript">
    $(function() {
        @if(Session::has('success'))
        toastr.success('{{ Session::get('success') }}');
        @endif
    });

</script>

@yield('script')

</body>
</html>