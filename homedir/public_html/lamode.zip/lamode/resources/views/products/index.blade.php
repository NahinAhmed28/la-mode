@extends('layouts.master')
@section('content')
    <h2>Variants</h2>
    <br />
<ol class="breadcrumb bc-3">

    <li>
        <a href="">
            <i class="entypo-home"></i>
            DashBoard
        </a>
    </li>


    <li class="active">
        <strong>Products</strong>
    </li>

</ol>

<a href="{{ route('products.create') }}"
   class="btn btn-info btn-sm btn-icon icon-left">
    Add New Product
    <i class="entypo-plus"></i>
</a>

<br>

<br>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="panel-title">
                    <strong>
                        Products
                    </strong>
                </div>
            </div>

            <div class="panel-body with-table">

                <table class="table table-bordered datatable" id="table-3" style="vertical-align: middle">
                    <thead>
                    <tr class="replace-inputs">
                        <th>SKU</th>
                        <th width="16%">Image</th>
                        <th>Prooduct Name</th>

                        <th width="25%">Stock</th>
                        <th>Price</th>
                        <th>Options</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($products as $key => $product)
                    <tr>
                        <td>{{ $product->sku }}</td>
                        <td>
                            @if($product->image == '')
                                <img src="{{ asset('assets/no_image.png') }}" alt="..." style="width: 100px; vertical-align: middle">
                            @else
                                <img src="{{ asset('uploads/product_images/thumbs/' . $product->image) }}" alt="..." style="width: 100px; vertical-align: middle">
                            @endif
                        </td>
                        <td>
                            {{ $product->name }}
                        </td>

                        <td align="center">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th width="20%"></th>
                                    @foreach($branches as $key => $branch)
                                        <th>{{ substr($branch->name, 0,4) }}</th>
                                    @endforeach
                                </tr>
                                </thead>
                                <tbody>
                                @if($product->category->has_variant == 1)
                                    @php $stocks = $product->stocks  @endphp
                                    @foreach($variants as $key => $variant)
                                        <tr>

                                            <td><b>{{ $variant->name }}</b></td>
                                            @foreach($branches as $key => $branch)
                                                @foreach($stocks as $stock)
                                                    @if($stock->variant_id == $variant->id && $stock->product_id == $product->id && $stock->branch_id == $branch->id)
                                                        <td>{{ $stock->stock  }}</td>
                                                    @endif
                                                @endforeach
                                            @endforeach
                                        </tr>
                                    @endforeach
                                @else
                                    @php $stocks = $product->stocks  @endphp
                                    <tr>

                                        <td><b>Stock</b></td>
                                        @foreach($branches as $key => $branch)
                                            @foreach($stocks as $stock)
                                                @if($stock->product_id == $product->id && $stock->branch_id == $branch->id)
                                                    <td>{{ $stock->stock  }}</td>
                                                @endif
                                            @endforeach
                                        @endforeach
                                    </tr>
                                @endif

                                </tbody>
                            </table>
                        </td>
                        <td>
                            {{ format_price($product->price) }}
                        </td>
                        <td>
                            <div class="btn-group">
                                <button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown">
                                    Action <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu dropdown-default" role="menu">
                                    <li>
                                        <a href="#" onclick="showAjaxModal('{{ route('products.show', $product->id) }}')">
                                            <i class="entypo-menu"></i> Details
                                        </a>
                                    </li>
                                    <li>
                                        <a href="{{ route('products.edit', $product->id) }}">
                                            <i class="entypo-pencil"></i> Edit
                                        </a>
                                    </li>

                                    <li class="divider"></li>
                                    <li>
                                        <a href="#" onclick="">
                                            <i class="entypo-archive"></i> Archive
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" onclick="confirm_modal('{{ route('products.delete', $product->id) }}')">
                                            <i class="entypo-trash"></i> Delete
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                    @endforeach
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>SKU</th>
                        <th>Prooduct Name</th>
                        <th>Category</th>
                        <th>Stock</th>
                        <th>Price</th>
                        <th>Options</th>
                    </tr>
                    </tfoot>
                </table>

            </div>
        </div>

    </div>
</div>

    <script type="text/javascript">

        jQuery( document ).ready( function( $ ) {
            var $table3 = jQuery("#table-3");

            var table3 = $table3.DataTable( {
                "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
            } );

            // Initalize Select Dropdown after DataTables is created
            $table3.closest( '.dataTables_wrapper' ).find( 'select' ).select2( {
                minimumResultsForSearch: -1
            });

            // Setup - add a text input to each footer cell
            $( '#table-3 tfoot th' ).each( function () {
                var title = $('#table-3 thead th').eq( $(this).index() ).text();
                $(this).html( '<input id="foot_' + title +'" type="text" class="form-control" placeholder="Search" />' );
            } );

            // disables search in the option column
            $('#foot_Options').attr("disabled",true);

            // Apply the search
            table3.columns().every( function () {
                var that = this;

                $( 'input', this.footer() ).on( 'keyup change', function () {
                    if ( that.search() !== this.value ) {
                        that
                            .search( this.value )
                            .draw();
                    }
                } );
            } );
        } );

    </script>
@endsection