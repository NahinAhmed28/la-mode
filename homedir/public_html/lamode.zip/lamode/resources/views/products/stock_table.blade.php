<table class="table table-bordered responsive">
    <thead>
    <tr>
        <th width="16%">Variant</th>
        @foreach($branches as $key => $branch)
            <th>{{ $branch->name }}</th>
        @endforeach
    </tr>
    </thead>
    <tbody>
    @if($category->has_variant == 1)
        @foreach($variants as $key => $variant)
            <tr>
                {{ Form::hidden('variant_id[]', $variant->id, array('id' => 'grand_total')) }}
                <td>{{ $variant->name }}</td>
                @foreach($branches as $key => $branch)
                    <td>{!! Form::number('stock_'.$branch->id.'[]', 0, array('class' => 'form-control')) !!}</td>
                @endforeach
            </tr>
        @endforeach
    @else
        <tr>
            <td>Stock</td>
            @foreach($branches as $key => $branch)
                <td>{!! Form::number('stock[]', 0, array('class' => 'form-control')) !!}</td>
            @endforeach
        </tr>
    @endif

    </tbody>
</table>