@extends('layouts.master')
@section('content')
<h2>Add Product</h2>
<br />
<ol class="breadcrumb bc-3">

    <li>
        <a href="">
            <i class="entypo-home"></i>
            Dashboard
        </a>
    </li>

    <li>
        <a href="">
            Inventory
        </a>
    </li>

    <li class="active">
        <strong>Add Product</strong>
    </li>

</ol>
@if (count($errors) > 0)
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
{!! Form::open(array('route' => 'products.store','method'=>'POST', 'class'=> 'form-horizontal form-groups-bordered', 'enctype' => "multipart/form-data")) !!}

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default" data-collapsed="0">
            <div class="panel-heading">
                <div class="panel-title">
                    Product Info
                </div>
            </div>
            <div class="panel-body">

                <div class="col-md-6">

                    <div class="form-group">
                        <label class="col-sm-3 control-label">SKU</label>
                        <div class="col-sm-9">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="entypo-code"></i></span>
                                {!! Form::text('sku', substr(md5(rand(0, 1000000)), 0, 7), array( 'class' => 'form-control')) !!}

                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 control-label">Product Name</label>
                        <div class="col-sm-9">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="entypo-menu"></i></span>
                                {!! Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control')) !!}

                            </div>
                        </div>
                    </div>


                    <div class="form-group">
                        <label class="col-sm-3 control-label">Category</label>
                        <div class="col-sm-9">
                            {!! Form::select('category_id', $category_list, null, array('id' => 'category_id', 'class' => 'form-control')) !!}
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 control-label">Description</label>
                        <div class="col-sm-9">
                            {!! Form::textarea('description', null, array('class' => 'form-control', 'size'=> '5x5')) !!}
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 control-label">Price</label>
                        <div class="col-sm-9">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="entypo-star"></i></span>
                                {!! Form::text('price', 0, array('placeholder' => 'Price','class' => 'form-control')) !!}
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 control-label">Mark Up(%)</label>
                        <div class="col-sm-9">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="entypo-star"></i></span>
                                {!! Form::text('markup', 0, array('placeholder' => 'Markup','class' => 'form-control')) !!}
                            </div>
                        </div>
                    </div>



                </div>

                <div class="col-md-6">

                    <div class="form-group">
                        <label class="col-sm-3 control-label">Image</label>
                        <div class="col-sm-9">

                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;" data-trigger="fileinput">
                                    <img src="{{ asset('assets/no_image.png') }}" alt="...">
                                </div>
                                <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px"></div>
                                <div>
									<span class="btn btn-white btn-file">
										<span class="fileinput-new">Select Image</span>
										<span class="fileinput-exists">Change</span>
										<input type="file" name="product_image" accept="image/*">
									</span>
                                    <a href="#" class="btn btn-orange fileinput-exists" data-dismiss="fileinput">Remove</a>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default" data-collapsed="0">
            <div class="panel-heading">
                <div class="panel-title">
                    Stocks
                </div>
            </div>
            <div class="panel-body">

                <div id="stock-table-holder">

                </div>


            </div>
        </div>
    </div>
</div>

<div class="row">
    <button type="submit" id="submit_button" class="btn btn-green btn-icon icon-left" style="margin-left: 12px;" onclick="show_alert()">
        Add Product
        <i class="entypo-check"></i>
    </button>
</div>
{!! Form::close() !!}

    <script type="text/javascript">

        $(function() {
            $('#category_id').on('change', function() {
                var category_id = $(this).val();

                var url = '{{ route("products.stock_table", ":category_id") }}';
                url = url.replace(':category_id', category_id);

                $.ajax({

                    type:'GET',

                    url: url,

                    success:function(response){

                        jQuery('#stock-table-holder').html(response);

                    }

                });

            }).change();


        });
    </script>
@endsection