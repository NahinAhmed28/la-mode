<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary" data-collapsed="0">
            <div class="panel-heading">
                <div class="panel-title" >
                    <i class="entypo-plus-circled"></i>
                    Transfer Stock
                </div>
            </div>
            <div class="panel-body">
                <form action="{{  }}" method="POST" id="validate-form" enctype="multipart/form-data">


                </form>
            </div>

        </div>
    </div>
</div>