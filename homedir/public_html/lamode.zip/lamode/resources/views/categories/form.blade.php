<div class="form-group">
    <label for="field-1" class="col-sm-3 control-label">Name</label>

    <div class="col-sm-5">
        {!! Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control', 'required' => 'required')) !!}
    </div>
</div>


<div class="clearfix"></div>
<div class="form-group">
    <label for="field-1" class="col-sm-3 control-label">Description</label>

    <div class="col-sm-5">
        {!! Form::text('description', null, array('placeholder' => 'Description','class' => 'form-control')) !!}
    </div>
</div>
<div class="clearfix"></div>
@php
    $val= [
        1 => 'Yes',
        0 => 'No'];
@endphp
<div class="form-group">
    <label class="col-sm-3 control-label">Has Variant</label>
    <div class="col-sm-5">
        {!! Form::select('has_variant', $val, null, array('class' => 'form-control')) !!}
    </div>
</div>
<div class="form-group">
    <div class="col-sm-offset-3 col-sm-5">
        <button type="submit" class="btn btn-info">
            @if (isset($category))
                {{ 'Update' }}
            @else
                {{ 'Create'  }}
            @endif
        </button>
    </div>
</div>