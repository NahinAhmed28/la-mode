<script src="{{asset('assets/js/jquery-1.11.3.min.js')}}"></script>

<!-- Imported styles -->
<link rel="stylesheet" href="{{ asset('assets/js/datatables/datatables.css') }}">
<link rel="stylesheet" href="{{ asset('assets/js/select2/select2-bootstrap.css') }}">
<link rel="stylesheet" href="{{ asset('assets/js/select2/select2.css') }}">
<link rel="stylesheet" href="{{ asset('assets/js/selectboxit/jquery.selectBoxIt.css') }}">
<link rel="stylesheet" href="{{ asset('assets/js/icheck/skins/flat/_all.css') }}">
<link rel="stylesheet" href="{{ asset('assets/css/font-icons/font-awesome/css/font-awesome.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/css/bootstrap-select.css') }}">

<!-- Bottom scripts (common) -->

<script src="{{ asset('assets/js/datatables/datatables.js') }}"></script>
<script src="{{ asset('assets/js/gsap/TweenMax.min.js') }}"></script>
<script src="{{ asset('assets/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js') }}"></script>
<script src="{{ asset('assets/js/bootstrap.js') }}"></script>
<script src="{{ asset('assets/js/joinable.js') }}"></script>
<script src="{{ asset('assets/js/resizeable.js') }}"></script>
<script src="{{ asset('assets/js/neon-api.js') }}"></script>
<script src="{{ asset('assets/js/toastr.js') }}"></script>
<script src="{{ asset('assets/js/jquery.validate.min.js') }}"></script>
<script src="{{ asset('assets/js/select2/select2.min.js') }}"></script>
<script src="{{ asset('assets/js/selectboxit/jquery.selectBoxIt.min.js') }}"></script>
<script src="{{ asset('assets/js/bootstrap-datepicker.js') }}"></script>
<script src="{{ asset('assets/js/icheck/icheck.min.js') }}"></script>
<script src="{{ asset('assets/js/fileinput.js') }}"></script>
<script src="{{ asset('assets/js/neon-chat.js') }}"></script>
<script src="{{ asset('assets/js/bootstrap-select.js') }}"></script>



{{--<script type="text/javascript" src="{{asset('assets/fancybox/jquery.fancybox.js?v=2.1.5')}}"></script>--}}
{{--<link rel="stylesheet" type="text/css" href="{{ asset('assets/fancybox/jquery.fancybox.css?v=2.1.5') }}" media="screen" />--}}


<!-- JavaScripts initializations and stuff -->
<script src="{{asset('assets/js/neon-custom.js')}}"></script>

<!-- Demo Settings -->
<script src="{{asset('assets/js/neon-demo.js')}}"></script>