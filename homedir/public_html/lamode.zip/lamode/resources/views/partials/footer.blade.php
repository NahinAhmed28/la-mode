<!-- Footer -->
<footer class="main">
    &copy; 2018 <strong>LaMode</strong> | <a href="http://creativeitem.com" target="_blank">Heisenberg Digital</a>
</footer>