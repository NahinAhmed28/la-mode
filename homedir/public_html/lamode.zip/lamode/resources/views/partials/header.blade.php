<div class="row">

    <!-- Profile Info and Notifications -->
    <div class="col-md-6 col-sm-8 clearfix">

        <ul class="user-info pull-left pull-none-xsm">

            <!-- Profile Info -->
            <li class="profile-info dropdown"><!-- add class "pull-right" if you want to place this from right -->

                <a href="/profile">
                    <img src="{{ asset('assets/images/no_user.jpg') }}"
                         alt="" class="img-circle" width="44" />
                    {{ Auth::user()->name }}

                </a>
            </li>

        </ul>


        <ul class="user-info pull-left pull-right-xs pull-none-xsm">

            <!-- Raw Notifications -->
            <li class="notifications dropdown">

                <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                    <i class="entypo-bell"></i>

                    <span class="badge badge-info">3</span>

                </a>

                <ul class="dropdown-menu">
                    <li class="top">
                        <p class="small">
                            <a href="index.php?admin/sales_order_list/order_pending"
                               class="pull-right">View</a>
                            You Have <strong>3</strong> Pending Orders
                        </p>
                    </li>
                </ul>

            </li>

            <li class="notifications dropdown">

                <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                    <i class="entypo-direction"></i>
                </a>

                <ul class="dropdown-menu">
                    <li>

                        <ul class="dropdown-menu-list scroller">

                            <li>
                                <a href="index.php?admin/sales_order_add">
                                    <i class="entypo-bell"></i> &nbsp; <b>New Sales Order</b>
                                </a>
                            </li>

                            <li>
                                <a href="index.php?admin/inventory_add">
                                    <i class="entypo-basket"></i> &nbsp; <b>New Product</b>
                                </a>
                            </li>
                            <li>
                                <a href="index.php?admin/user_add">
                                    <i class="entypo-user"></i> &nbsp; <b>New User</b>
                                </a>
                            </li>

                        </ul>
                    </li>
                </ul>

            </li>

        </ul>

    </div>

    <!-- Raw Links -->
    <div class="col-md-6 col-sm-4 clearfix hidden-xs">

        <ul class="list-inline links-list pull-right">

            <li>
                <a href="{{ route('logout') }}"
                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                    {{ __('Logout') }}
                </a>
            </li>
            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                @csrf
            </form>
        </ul>

    </div>

</div>

<hr />