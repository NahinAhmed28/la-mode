<div class="sidebar-menu">

    <div class="sidebar-menu-inner">

        <header class="logo-env">

            <!-- logo -->
            <div class="logo">
                <a href="">
                    <img src="{{ asset('assets/images/logo.jpg') }}" width="160" alt="" />
                </a>
            </div>

            <!-- logo collapse icon -->
            <div class="sidebar-collapse">
                <a href="#" class="sidebar-collapse-icon with-animation"><!-- add class "with-animation" if you want sidebar to have animation during expanding/collapsing transition -->
                    <i class="entypo-menu"></i>
                </a>
            </div>


            <!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
            <div class="sidebar-mobile-menu visible-xs">
                <a href="#" class="with-animation"><!-- add class "with-animation" to support animation -->
                    <i class="entypo-menu"></i>
                </a>
            </div>

        </header>


        <ul id="main-menu" class="main-menu">
            <!-- add class "multiple-expanded" to allow multiple submenus to open -->
            <!-- class "auto-inherit-active-class" will automatically add "active" class for parent elements who are marked already with class "active" -->


            <!-- ADMIN DASHBOARD -->
            <li class="">
                <a href="/">
                    <i class="entypo-gauge"></i>
                    <span class="title">Dashboard</span>
                </a>
            </li>

            <li class="">
                <a href="{{ route('dashboards.google_sheet') }}">
                    <i class="entypo-doc-text"></i>
                    <span class="title">Google Sheets</span>
                </a>
            </li>

            <!-- USERS -->
            <li class="{{ areActiveRoutes(['users.index']) }}">
                <a href="{{ route('users.index') }}">
                    <i class="entypo-users"></i>
                    <span class="title">Users</span>
                </a>
            </li>

            <!-- SALES ORDERS -->


            <!-- PURCHASE ORDERS -->


            <!-- INVENTORY -->
            <li class="{{ areOpenSubs(['categories.index', 'variants.index', 'products.get_list', 'products.create', 'products.edit']) }} {{ areActiveRoutes(['categories.index', 'variants.index', 'products.index', 'products.create']) }}">
                <a href="">
                    <i class="entypo-bag"></i>
                    <span class="title">Inventory</span>
                </a>
                <ul>
                    <li class="{{ areActiveRoutes(['products.create']) }}">
                        <a href="{{ route('products.create') }}">
                            <i class="entypo-dot"></i>
                            <span class="title">New Product</span>
                        </a>
                    </li>
                    <li class="{{ areActiveRoutes(['products.get_list']) }}">
                        <a href="{{ route('products.get_list', 'all') }}">
                            <i class="entypo-dot"></i>
                            <span class="title">Products</span>
                        </a>
                    </li>
                    <li class="{{ areActiveRoutes(['categories.index']) }}">
                        <a href="{{ route('categories.index') }}">
                            <i class="entypo-dot"></i>
                            <span class="title">Product Category</span>
                        </a>
                    </li>

                    <li class="{{ areActiveRoutes(['variants.index']) }}">
                        <a href="{{ route('variants.index') }}">
                            <i class="entypo-dot"></i>
                            <span class="title">Product Variant</span>
                        </a>
                    </li>

                </ul>
            </li>

            <!-- Warehouse -->
            <li class="{{ areActiveRoutes(['branches.index']) }}">
                <a href="{{ route('branches.index') }}">
                    <i class="entypo-key"></i>
                    <span class="title">Branches</span>
                </a>
            </li>

            <!-- Warehouse -->

            <!-- SALES ORDERS -->
            <li class="{{ areOpenSubs(['sales.get_list', 'sales.create']) }} {{ areActiveRoutes(['sales.get_list', 'sales.create']) }}">
                <a href="">
                    <i class="entypo-bell"></i>
                    <span class="title">Sales Order</span>
                </a>
                <ul>
                    <li class="{{ areActiveRoutes(['sales.create']) }}">
                        <a href="{{ route('sales.create') }}">
                            <i class="entypo-dot"></i>
                            <span class="title">Add New Order</span>
                        </a>
                    </li>
                    <li class="{{ areActiveRoutes(['sales.get_list']) }}">
                        <a href="{{ route('sales.get_list', 'all') }}">
                            <i class="entypo-dot"></i>
                            <span class="title">Order List</span>
                        </a>
                    </li>
                </ul>
            </li>


            <li class="{{ areOpenSubs(['customers.index', 'customers.create']) }} {{ areActiveRoutes(['customers.index', 'customers.create']) }}">
                <a href="">
                    <i class="entypo-users"></i>
                    <span class="title">Customers</span>
                </a>
                <ul>
                    <li class="{{ areActiveRoutes(['customers.create']) }}">
                        <a href="{{ route('customers.create') }}">
                            <i class="entypo-dot"></i>
                            <span class="title">Add New Customer</span>
                        </a>
                    </li>
                    <li class="{{ areActiveRoutes(['customers.index']) }}">
                        <a href="{{ route('customers.index') }}">
                            <i class="entypo-dot"></i>
                            <span class="title">Customer List</span>
                        </a>
                    </li>
                </ul>
            </li>

            <!-- REPORTS -->
            <li class="">
                <a href="">
                    <i class="entypo-chart-area"></i>
                    <span class="title">Reports</span>
                </a>
                <ul>
                    <li class="">
                        <a href="">
                            <i class="entypo-dot"></i>
                            <span class="title">Sales Order Report</span>
                        </a>
                    </li>

                </ul>
            </li>

            <!-- SETTINGS -->
            <li class="">
                <a href="">
                    <i class="entypo-cog"></i>
                    <span class="title">Settings</span>
                </a>
                <ul>
                    <li class="">
                        <a href="">
                            <i class="entypo-dot"></i>
                            <span class="title">System Settings</span>
                        </a>
                    </li>

                </ul>
            </li>

            <!-- ACCOUNT -->
            <li class="">
                <a href="">
                    <i class="entypo-key"></i>
                    <span class="title">Profile</span>
                </a>
            </li>


        </ul>

    </div>

</div>
