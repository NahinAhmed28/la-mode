@extends('layouts.master')
@section('content')
    <h2>Variants</h2>
    <br />
    <ol class="breadcrumb bc-3">

        <li>
            <a href="">
                <i class="entypo-home"></i>
                DashBoard
            </a>
        </li>


        <li class="active">
            <strong>Google Sheets</strong>
        </li>

    </ol>



    <br>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <div class="panel-title">
                        <strong>
                            Google Sheet
                        </strong>
                    </div>
                </div>

                <div class="panel-body with-table">

                    <iframe src="https://docs.google.com/spreadsheets/d/e/2PACX-1vSaG7DpfX09DvAoiqGZQvCjUnGpXMWW58Vhey6FSXw_Fsq9vNOTFcLfaJxFpAJMz52HROCNg93oAwfG/pubhtml?widget=true&amp;headers=false"></iframe>

                </div>
            </div>

        </div>
    </div>
<style>
    iframe{
        width: 100%;
        height: 600px;
    }
</style>

@endsection