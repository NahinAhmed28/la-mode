<?php $__env->startSection('content'); ?>
    <h2>Add Product</h2>
    <br />
    <ol class="breadcrumb bc-3">

        <li>
            <a href="">
                <i class="entypo-home"></i>
                Dashboard
            </a>
        </li>

        <li>
            <a href="">
                Inventory
            </a>
        </li>

        <li class="active">
            <strong>Edit Product</strong>
        </li>

    </ol>
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php echo Form::model($product, array('route' => ['products.update', $product->id],'method'=>'PATCH', 'class'=> 'form-horizontal form-groups-bordered', 'enctype' => "multipart/form-data")); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default" data-collapsed="0">
                <div class="panel-heading">
                    <div class="panel-title">
                        Product Info
                    </div>
                </div>
                <div class="panel-body">

                    <div class="col-md-6">

                        <div class="form-group">
                            <label class="col-sm-3 control-label">SKU</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="entypo-code"></i></span>
                                    <?php echo Form::text('sku', null, array( 'class' => 'form-control')); ?>


                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-3 control-label">Product Name</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="entypo-menu"></i></span>
                                    <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control')); ?>


                                </div>
                            </div>
                        </div>



                        <div class="form-group">
                            <label class="col-sm-3 control-label">Description</label>
                            <div class="col-sm-9">
                                <?php echo Form::textarea('description', null, array('class' => 'form-control', 'size'=> '5x5')); ?>

                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-3 control-label">Price</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="entypo-star"></i></span>
                                    <?php echo Form::text('price', null, array('placeholder' => 'Price','class' => 'form-control')); ?>

                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-3 control-label">Mark Up(%)</label>
                            <div class="col-sm-9">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="entypo-star"></i></span>
                                    <?php echo Form::text('markup', null, array('placeholder' => 'Markup','class' => 'form-control')); ?>

                                </div>
                            </div>
                        </div>



                    </div>

                    <div class="col-md-6">

                        <div class="form-group">
                            <label class="col-sm-3 control-label">Image</label>
                            <div class="col-sm-9">

                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                    <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;" data-trigger="fileinput">
                                        <?php if($product->image == ''): ?>
                                        <img src="<?php echo e(asset('assets/no_image.png')); ?>" alt="...">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('uploads/product_images/thumbs/' . $product->image)); ?>" alt="...">
                                        <?php endif; ?>
                                    </div>
                                    <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px"></div>
                                    <div>
									<span class="btn btn-white btn-file">
										<span class="fileinput-new">Select Image</span>
										<span class="fileinput-exists">Change</span>
										<input type="file" name="product_image" accept="image/*">
									</span>
                                        <a href="#" class="btn btn-orange fileinput-exists" data-dismiss="fileinput">Remove</a>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default" data-collapsed="0">
                <div class="panel-heading">
                    <div class="panel-title">
                        Stocks
                    </div>
                </div>
                <div class="panel-body">

                    <table class="table table-bordered responsive">
                        <thead>
                        <tr>
                            <th width="16%">Variant</th>
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th><?php echo e($branch->name); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if($product->category->has_variant == 1): ?>
                            <?php $__currentLoopData = $variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php echo e(Form::hidden('variant_id[]', $variant->id, array('id' => 'grand_total'))); ?>

                                    <td><?php echo e($variant->name); ?></td>
                                    <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $stock = \App\Stock::where([
                                                ['product_id', $product->id],
                                                ['variant_id',  $variant->id],
                                                ['branch_id', $branch->id]])->get()->first()->stock ?>
                                        <td><?php echo Form::number('stock_'.$branch->id.'[]', $stock, array('class' => 'form-control')); ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td>Stock</td>
                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $stock = \App\Stock::where([
                                                ['product_id', $product->id],
                                                ['branch_id', $branch->id]])->get()->first()->stock ?>
                                    <td><?php echo Form::number('stock[]', $stock, array('class' => 'form-control')); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <button type="submit" id="submit_button" class="btn btn-green btn-icon icon-left" style="margin-left: 12px;" onclick="show_alert()">
            Update Product
            <i class="entypo-check"></i>
        </button>
    </div>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>