<?php $__env->startSection('content'); ?>
    <h2>Categories</h2>
    <br />
<ol class="breadcrumb bc-3">

    <li>
        <a href="">
            <i class="entypo-home"></i>
            DashBoard
        </a>
    </li>


    <li class="active">
        <strong>Product Categories</strong>
    </li>

</ol>

<a href="#" onclick="showAjaxModal('<?php echo e(route('categories.create')); ?>');"
   class="btn btn-info btn-sm btn-icon icon-left">
    Add New Category
    <i class="entypo-plus"></i>
</a>

<br>

<br>
<div class="row">
    <div class="col-md-12">
        <table class="table table-bordered responsive">
            <thead>
            <tr>
                <th width="3%">#</th>
                <th>Name</th>
                <th>Description</th>
                <th width="16%">Options</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key+1); ?></td>
                <td><?php echo e($category->name); ?></td>
                <td><?php echo e($category->description); ?></td>
                <td>
                    <div class="btn-group">
                        <button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown">
                            Action <span class="caret"></span>
                        </button>
                        <ul class="dropdown-menu dropdown-default" role="menu">
                            <li>
                                <a href="#" onclick="showAjaxModal('<?php echo e(route('categories.edit', $category->id)); ?>')">
                                    <i class="entypo-pencil"></i> Edit
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a href="#" onclick="confirm_modal('<?php echo e(route('categories.delete', $category->id)); ?>')">
                                    <i class="entypo-trash"></i> Delete
                                </a>
                            </li>
                        </ul>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>