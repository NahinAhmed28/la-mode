<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default" data-collapsed="0">
            <div class="panel-heading">
                <div class="panel-title">
                    Customer Info
                </div>
            </div>
            <div class="panel-body">

                <div class="col-md-6">

                    <div class="form-group">
                        <label class="col-sm-3 control-label">Name</label>
                        <div class="col-sm-9">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="entypo-menu"></i></span>
                                <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control')); ?>


                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 control-label">Phone</label>
                        <div class="col-sm-9">
                            <?php echo Form::text('phone', null, array('placeholder' => 'phone', 'class' => 'form-control')); ?>

                        </div>
                    </div>



                    <div class="form-group">
                        <label class="col-sm-3 control-label">Email</label>
                        <div class="col-sm-9">
                            <?php echo Form::text('email', null, array('placeholder' => 'Email','class' => 'form-control')); ?>

                        </div>
                    </div>

                    <?php
                        $val= [
                            'Male' => 'Male',
                            'Female' => 'Female'];
                    ?>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Gender</label>
                        <div class="col-sm-9">
                            <?php echo Form::select('gender', $val, null, array('class' => 'form-control')); ?>

                        </div>
                    </div>



                </div>

                <div class="col-md-6">
                    <div class="col-sm-12">
                        <!-- user address fields -->

                        <div class="col-sm-12">
                            <?php echo Form::text('address1', null, array('placeholder' => 'Address Line 1','class' => 'form-control')); ?>

                        </div>

                        <div class="col-sm-12">
                            <label class="control-label">&nbsp;</label>
                            <?php echo Form::text('address2', null, array('placeholder' => 'Address Line 1','class' => 'form-control')); ?>

                        </div>

                        <div class="col-sm-6">
                            <label class="control-label">City</label>
                            <?php echo Form::text('city', null, array('placeholder' => 'City','class' => 'form-control')); ?>

                        </div>

                        <div class="col-sm-6">
                            <label class="control-label">Zip Code</label>
                            <?php echo Form::text('zipcode', null, array('placeholder' => 'Zip Code','class' => 'form-control')); ?>

                        </div>





                        <label class="control-label"></label>
                        <div class="col-sm-12" style="margin-top: 15px;">
                            <button type="submit" id="submit_button" class="btn btn-green btn-icon icon-left">
                                Create Customer
                                <i class="entypo-check"></i>
                            </button>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>