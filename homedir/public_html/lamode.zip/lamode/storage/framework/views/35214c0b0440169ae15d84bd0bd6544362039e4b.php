<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default" data-collapsed="0">
            <div class="panel-heading">
                <div class="panel-title">
                    Customer Info
                </div>
            </div>
            <div class="panel-body">

                <div class="col-md-6">

                    <div class="form-group">
                        <label class="col-sm-3 control-label">Name</label>
                        <div class="col-sm-9">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="entypo-menu"></i></span>
                                <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control')); ?>


                            </div>
                        </div>
                    </div>


                    <div class="form-group">
                        <label class="col-sm-3 control-label">Email</label>
                        <div class="col-sm-9">
                            <?php echo Form::text('email', null, array('placeholder' => 'Email','class' => 'form-control')); ?>

                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 control-label">Password</label>
                        <div class="col-sm-9">
                            <?php echo Form::password('password', array('placeholder' => 'Password', 'class' => 'form-control')); ?>

                        </div>
                    </div>

                    <?php
                        $val= [
                            2 => 'Regular',
                            3 => 'E-commerce',
                            1 => 'Admin'];
                    ?>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">User Type</label>
                        <div class="col-sm-9">
                            <?php echo Form::select('user_type', $val, null, array('id' => 'user_type','class' => 'form-control')); ?>

                        </div>
                    </div>

                    <div id="branch-holder">
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Branch</label>
                            <div class="col-sm-9">
                                <?php echo Form::select('branch_id', $branch_list, null, array( 'class' => 'form-control')); ?>

                            </div>
                        </div>
                    </div>
                    <label class="control-label"></label>
                    <div class="col-sm-12" style="margin-top: 15px;">
                        <button type="submit" id="submit_button" class="btn btn-green btn-icon icon-left">
                            <?php if(isset($user)): ?>
                                <?php echo e('Update User'); ?>

                            <?php else: ?>
                                <?php echo e('Create User'); ?>

                            <?php endif; ?>
                            <i class="entypo-check"></i>
                        </button>
                    </div>

                </div>


            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(function() {
        $('#user_type').on('change', function() {
            var user_type = $(this).val();

            console.log(user_type);
            if(user_type == '2')
            {
                $('#branch-holder').show();
            }
            else {
                $('#branch-holder').hide();
            }

        }).change();


    });
</script>