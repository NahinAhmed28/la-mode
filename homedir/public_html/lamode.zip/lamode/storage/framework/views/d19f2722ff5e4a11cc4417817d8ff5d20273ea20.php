<div class="sidebar-menu">

    <div class="sidebar-menu-inner">

        <header class="logo-env">

            <!-- logo -->
            <div class="logo">
                <a href="">
                    <img src="<?php echo e(asset('assets/images/logo.jpg')); ?>" width="160" alt="" />
                </a>
            </div>

            <!-- logo collapse icon -->
            <div class="sidebar-collapse">
                <a href="#" class="sidebar-collapse-icon with-animation"><!-- add class "with-animation" if you want sidebar to have animation during expanding/collapsing transition -->
                    <i class="entypo-menu"></i>
                </a>
            </div>


            <!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
            <div class="sidebar-mobile-menu visible-xs">
                <a href="#" class="with-animation"><!-- add class "with-animation" to support animation -->
                    <i class="entypo-menu"></i>
                </a>
            </div>

        </header>


        <ul id="main-menu" class="main-menu">
            <!-- add class "multiple-expanded" to allow multiple submenus to open -->
            <!-- class "auto-inherit-active-class" will automatically add "active" class for parent elements who are marked already with class "active" -->


            <!-- ADMIN DASHBOARD -->
            <li class="">
                <a href="/">
                    <i class="entypo-gauge"></i>
                    <span class="title">Dashboard</span>
                </a>
            </li>

            <li class="">
                <a href="<?php echo e(route('dashboards.google_sheet')); ?>">
                    <i class="entypo-doc-text"></i>
                    <span class="title">Google Sheets</span>
                </a>
            </li>

            <!-- USERS -->
            <li class="<?php echo e(areActiveRoutes(['users.index'])); ?>">
                <a href="<?php echo e(route('users.index')); ?>">
                    <i class="entypo-users"></i>
                    <span class="title">Users</span>
                </a>
            </li>

            <!-- SALES ORDERS -->


            <!-- PURCHASE ORDERS -->


            <!-- INVENTORY -->
            <li class="<?php echo e(areOpenSubs(['categories.index', 'variants.index', 'products.get_list', 'products.create', 'products.edit'])); ?> <?php echo e(areActiveRoutes(['categories.index', 'variants.index', 'products.index', 'products.create'])); ?>">
                <a href="">
                    <i class="entypo-bag"></i>
                    <span class="title">Inventory</span>
                </a>
                <ul>
                    <li class="<?php echo e(areActiveRoutes(['products.create'])); ?>">
                        <a href="<?php echo e(route('products.create')); ?>">
                            <i class="entypo-dot"></i>
                            <span class="title">New Product</span>
                        </a>
                    </li>
                    <li class="<?php echo e(areActiveRoutes(['products.get_list'])); ?>">
                        <a href="<?php echo e(route('products.get_list', 'all')); ?>">
                            <i class="entypo-dot"></i>
                            <span class="title">Products</span>
                        </a>
                    </li>
                    <li class="<?php echo e(areActiveRoutes(['categories.index'])); ?>">
                        <a href="<?php echo e(route('categories.index')); ?>">
                            <i class="entypo-dot"></i>
                            <span class="title">Product Category</span>
                        </a>
                    </li>

                    <li class="<?php echo e(areActiveRoutes(['variants.index'])); ?>">
                        <a href="<?php echo e(route('variants.index')); ?>">
                            <i class="entypo-dot"></i>
                            <span class="title">Product Variant</span>
                        </a>
                    </li>

                </ul>
            </li>

            <!-- Warehouse -->
            <li class="<?php echo e(areActiveRoutes(['branches.index'])); ?>">
                <a href="<?php echo e(route('branches.index')); ?>">
                    <i class="entypo-key"></i>
                    <span class="title">Branches</span>
                </a>
            </li>

            <!-- Warehouse -->

            <!-- SALES ORDERS -->
            <li class="<?php echo e(areOpenSubs(['sales.get_list', 'sales.create'])); ?> <?php echo e(areActiveRoutes(['sales.get_list', 'sales.create'])); ?>">
                <a href="">
                    <i class="entypo-bell"></i>
                    <span class="title">Sales Order</span>
                </a>
                <ul>
                    <li class="<?php echo e(areActiveRoutes(['sales.create'])); ?>">
                        <a href="<?php echo e(route('sales.create')); ?>">
                            <i class="entypo-dot"></i>
                            <span class="title">Add New Order</span>
                        </a>
                    </li>
                    <li class="<?php echo e(areActiveRoutes(['sales.get_list'])); ?>">
                        <a href="<?php echo e(route('sales.get_list', 'all')); ?>">
                            <i class="entypo-dot"></i>
                            <span class="title">Order List</span>
                        </a>
                    </li>
                </ul>
            </li>


            <li class="<?php echo e(areOpenSubs(['customers.index', 'customers.create'])); ?> <?php echo e(areActiveRoutes(['customers.index', 'customers.create'])); ?>">
                <a href="">
                    <i class="entypo-users"></i>
                    <span class="title">Customers</span>
                </a>
                <ul>
                    <li class="<?php echo e(areActiveRoutes(['customers.create'])); ?>">
                        <a href="<?php echo e(route('customers.create')); ?>">
                            <i class="entypo-dot"></i>
                            <span class="title">Add New Customer</span>
                        </a>
                    </li>
                    <li class="<?php echo e(areActiveRoutes(['customers.index'])); ?>">
                        <a href="<?php echo e(route('customers.index')); ?>">
                            <i class="entypo-dot"></i>
                            <span class="title">Customer List</span>
                        </a>
                    </li>
                </ul>
            </li>

            <!-- REPORTS -->
            <li class="">
                <a href="">
                    <i class="entypo-chart-area"></i>
                    <span class="title">Reports</span>
                </a>
                <ul>
                    <li class="">
                        <a href="">
                            <i class="entypo-dot"></i>
                            <span class="title">Sales Order Report</span>
                        </a>
                    </li>

                </ul>
            </li>

            <!-- SETTINGS -->
            <li class="">
                <a href="">
                    <i class="entypo-cog"></i>
                    <span class="title">Settings</span>
                </a>
                <ul>
                    <li class="">
                        <a href="">
                            <i class="entypo-dot"></i>
                            <span class="title">System Settings</span>
                        </a>
                    </li>

                </ul>
            </li>

            <!-- ACCOUNT -->
            <li class="">
                <a href="">
                    <i class="entypo-key"></i>
                    <span class="title">Profile</span>
                </a>
            </li>


        </ul>

    </div>

</div>
