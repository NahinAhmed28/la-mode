<!DOCTYPE html>
<html lang="en">


<title>LA Mode</title>
<?php echo $__env->make('partials.metas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('partials.stylesheets', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('partials.javascripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- INCLUDES THE CSS FILES AND MAIN JQUERY LIBRARY -->

<body class="page-body" data-url="http://neon.dev">

<div class="page-container">

    <!-- INCLUDES THE NAVIGATION MENU FOR USERS -->
    <?php echo $__env->make('partials.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="main-content">

        <!-- INCLUDES THE HEADER -->
        <?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <!-- INCLUDES THE MAIN BODY FOR EACH PAGE -->
        <?php echo $__env->yieldContent('content'); ?>

    <!-- INCLUDES THE FOOTER -->
        <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>

</div>

<!-- INCLUDES ALL JAVASCRIPT FILES -->
<?php echo $__env->make('partials.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
    $(function() {
        <?php if(Session::has('success')): ?>
        toastr.success('<?php echo e(Session::get('success')); ?>');
        <?php endif; ?>
    });

</script>

<?php echo $__env->yieldContent('script'); ?>

</body>
</html>