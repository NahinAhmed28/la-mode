<tr class="product-row">
    <td>
        <?php echo Form::select('product_ids[]', [ null=> 'Select Product' ]+ $product_list, null, array('class' => 'form-control select-2 product_select', 'required' => 'required')); ?>

        <?php echo e(Form::hidden('product_id[]',  null, array('class' => 'product_id'))); ?>

    </td>
    <td>
        <?php echo Form::select('variant_id[]', $variant_list, null, array('class' => 'form-control variant_select table-input-height', 'required' => 'required')); ?>

    </td>
    <td>
        <?php echo Form::text('stock', null, array('class' => 'form-control stock table-input-height', 'disabled' => 'disabled')); ?>

    </td>
    <td>
        <?php echo Form::number('qty[]', 1, array('class' => 'form-control qty-product table-input-height')); ?>

    </td>
    <td>
        <?php echo Form::text('price', null, array('class' => 'form-control price table-input-height', 'disabled' => 'disabled')); ?>

    </td>
    <td><?php echo Form::number('discount[]', 0, array('class' => 'form-control discount-product table-input-height')); ?>

        <?php echo e(Form::hidden('discount_amount_product[]',  0, array('class' => 'discount-amount'))); ?></td>

    <td>
        <?php echo e(Form::hidden('total_amount_product[]',  0, array('class' => 'total-product'))); ?>

        <?php echo Form::text('sub_product[]', 0, array('class' => 'form-control subtotal-product table-input-height', 'disabled' => 'disabled')); ?></td>
    <td>
        <a href="javascript:void(0)" class="delete-row">
            <i class="glyphicon glyphicon-remove" style="color: #676767; "></i>
        </a>

    </td>
</tr>