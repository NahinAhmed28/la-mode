
<link rel="icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/js/jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/font-icons/entypo/css/entypo.css')); ?>">
<link rel="stylesheet" href="//fonts.googleapis.com/css?family=Noto+Sans:400,700,400italic">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/neon-core.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/neon-theme.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/neon-forms.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">





<!-- AMCHARTS -->
<script src="<?php echo e(asset('assets/amcharts/amcharts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/amcharts/serial.js')); ?>"></script>
<script src="<?php echo e(asset('assets/amcharts/pie.js')); ?>"></script>
<script src="<?php echo e(asset('assets/amcharts/themes/light.js')); ?>"></script>
<script src="<?php echo e(asset('assets/amcharts/plugins/export/export.js')); ?>"></script>
<script src="<?php echo e(asset('assets/amcharts/plugins/export/export.css')); ?>"></script>