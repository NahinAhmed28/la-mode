<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary" data-collapsed="0">
            <div class="panel-heading">
                <div class="panel-title" >
                    <i class="entypo-plus-circled"></i>
                   <?php echo e($product->name); ?>

                </div>
            </div>
            <div class="panel-body">
                <div id="product_info">
                    <div class="col-sm-4">
                        <img src="<?php echo e(asset('uploads/product_images/thumbs/' . $product->image)); ?>" class="img-responsive">
                        <br>
                        <?php echo e($product->description); ?>

                        <br><br>
                        <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-info btn-icon icon-left btn-sm"
                                >
                            Edit Product
                            <i class="entypo-pencil"></i>
                        </a>
                    </div>

                    <div class="col-sm-1"></div>

                    <div class="col-sm-6">
                        <table class="table table-responsive">
                            <tbody>
                            <tr>
                                <td style="border: none;">
                                    <strong>SKU</strong>
                                </td>
                                <td style="border: none;">
                                    <strong>:</strong>
                                </td>
                                <td style="border: none;">
                                    <strong><?php echo e($product->sku); ?></strong>
                                </td>
                            </tr>
                            <tr>
                                <td style="border: none;">
                                    <strong>Category</strong>
                                </td>
                                <td style="border: none;">
                                    <strong>:</strong>
                                </td>
                                <td style="border: none;">
                                    <strong>
                                        <?php echo e($product->category->name); ?>

                                    </strong>
                                </td>
                            </tr>
                            <tr>
                                <td style="border: none;">
                                    <strong>Price</strong>
                                </td>
                                <td style="border: none;">
                                    <strong>:</strong>
                                </td>
                                <td style="border: none;">
                                    <strong>
                                        <?php echo e(format_price($product->price)); ?>

                                    </strong>
                                </td>
                            </tr>
                            <tr>
                                <td style="border: none;">
                                    <strong>Mark Up</strong>
                                </td>
                                <td style="border: none;">
                                    <strong>:</strong>
                                </td>
                                <td style="border: none;">
                                    <strong><?php echo e($product->markup); ?></strong>
                                </td>
                            </tr>

                            <tr>
                                <td style="border: none;">
                                    <strong>Date Created</strong>
                                </td>
                                <td style="border: none;">
                                    <strong>:</strong>
                                </td>
                                <td style="border: none;">
                                    <strong>
                                        <?php echo e(myDateFormat($product->created_at)); ?>

                                        
                                    </strong>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>




                    <div class="clearfix"></div>
                    <div class="col-md-12">
                        <h2>Stocks</h2>
                        <table class="table table-bordered table-responsive">
                            <thead>
                            <tr>
                                <th width="20%">Variant</th>
                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th><?php echo e($branch->name); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if($product->category->has_variant == 1): ?>
                                <?php $stocks = $product->stocks  ?>
                                <?php $__currentLoopData = $variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td><b><?php echo e($variant->name); ?></b></td>
                                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($stock->variant_id == $variant->id && $stock->product_id == $product->id && $stock->branch_id == $branch->id): ?>
                                                    <td><?php echo e($stock->stock); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <?php $stocks = $product->stocks  ?>
                                <tr>

                                    <td><b>Stock</b></td>
                                    <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($stock->product_id == $product->id && $stock->branch_id == $branch->id): ?>
                                                <td><?php echo e($stock->stock); ?></td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>