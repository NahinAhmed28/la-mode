<div class="form-group">
    <label for="field-1" class="col-sm-3 control-label">Name</label>

    <div class="col-sm-5">
        <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control', 'required' => 'required')); ?>

    </div>
</div>

<div class="clearfix"></div>
<div class="form-group">
    <label for="field-1" class="col-sm-3 control-label">Description</label>

    <div class="col-sm-5">
        <?php echo Form::text('description', null, array('placeholder' => 'Description','class' => 'form-control')); ?>

    </div>
</div>

<div class="clearfix"></div>
<div class="form-group">
    <label for="field-2" class="col-sm-3 control-label">Category</label>
    <div class="col-sm-5">
        <?php echo Form::select('category_id', $category_list, null, array('class' => 'form-control')); ?>

    </div>
</div>
<div class="form-group">
    <div class="col-sm-offset-3 col-sm-5">
        <button type="submit" class="btn btn-info">
            <?php if(isset($variant)): ?>
                <?php echo e('Update'); ?>

            <?php else: ?>
                <?php echo e('Create'); ?>

            <?php endif; ?>
        </button>
    </div>
</div>