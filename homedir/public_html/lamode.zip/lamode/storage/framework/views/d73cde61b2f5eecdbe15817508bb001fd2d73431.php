<?php $__env->startSection('content'); ?>
    <ol class="breadcrumb bc-3">

        <li>
            <a href="">
                <i class="entypo-home"></i>
                Dashboard
            </a>
        </li>

        <li>
            <a href="">
                Sales Orders
            </a>
        </li>

        <li class="active">
            <strong>View Order</strong>
        </li>

    </ol>

    <?php if($sale->status == 3): ?>
    <div class="row">
        <div class="col-md-12">
            <div class="alert alert-danger">
                <i class="entypo-cancel"></i> <strong>This Order has Been Cancelled</strong>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-12">

            <div class="panel panel-primary">
                <div class="panel-heading">
                    <div class="panel-title" style="color: #676767; font-size: 14px;">
                        <strong>Sales Order #<?php echo e($sale->code); ?></strong>
                    </div>

                    <div class="panel-options">


                            <?php if($sale->status != 2): ?>
                        <a href="#"
                           class="tooltip-primary" data-toggle="tooltip"
                           data-placement="top" title="" data-original-title="Mark as Delivered">
                            <i class="glyphicon glyphicon-ok" style="color: #676767;"></i>
                        </a>
                        &nbsp; &nbsp;
                            <?php endif; ?>
                        <a href="#" data-rel="collapse" class="tooltip-primary" data-toggle="tooltip"
                           data-placement="top" title="" data-original-title="Info">
                            <i class="glyphicon glyphicon-info-sign" style="color: #676767;"></i>
                        </a>

                    </div>
                </div>

                <!-- panel body -->
                <div class="panel-body">

                    <div class="col-sm-4">

                        <h5 style="color: #949494;"><?php echo e($sale->customer->name); ?></h5>
                        <p>
                            <i class="entypo-mail"></i> &nbsp;
                            <?php echo e($sale->customer->email); ?>

                        </p>
                        <p>
                            <i class="entypo-phone"></i> &nbsp;
                            <?php echo e($sale->customer->phone); ?>

                        </p>
                    </div>
                    <div class="col-sm-4">
                        <h5 style="color: #707070;">Details</h5>
                        <p>
                            <strong>Branch :</strong> <?php echo e($sale->branch->name); ?>

                        </p>
                        <p>
                            <strong>Order Type :</strong> <?php echo e($sale->order_type); ?>

                        </p>
                        <p>
                            <strong>Payment Type :</strong> <?php echo e($sale->payment_type); ?>

                        </p>
                        <?php if($sale->order_type != 'regular'): ?>
                        <p>
                            <strong>Shipment No :</strong> <?php echo e($sale->shipment_no); ?>

                        </p>

                            <p>
                                <strong>Delivery Type :</strong>  <?php echo e($sale->delivery_type); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="col-sm-4">
                        <h5 style="color: #707070;">Address</h5>
                        <p>
                            <?php echo e($sale->address1); ?>,
                            <?php echo e($sale->address2); ?>

                        </p>
                        <p>
                            <strong>City :</strong> <?php echo e($sale->city); ?>

                        </p>
                        <p>
                            <strong>Zipcode :</strong> <?php echo e($sale->zipcode); ?>

                        </p>

                        <p>
                            <strong>Order Date :</strong> <?php echo e(date('D, d M Y' , $sale->order_date)); ?>

                        </p>

                    </div>

                </div>
            </div>

        </div>
    </div>

    <hr />


    <div class="row" style="font-size: 13px; margin-left: 5px;">

        <?php if($sale->status == 0): ?><i class="fa fa-bell" style="color: #fad839;"></i>
        Pending &nbsp;
        <i class="fa fa-chevron-right"></i> &nbsp;<?php endif; ?>

        <i class="fa fa-circle" <?php if($sale->status != 0): ?> style="color:#00a651;"<?php endif; ?>></i>
        Confirmed &nbsp;
        <i class="fa fa-chevron-right"></i> &nbsp;


        <i class="fa fa-circle" <?php if($sale->status == 2): ?> style="color:#00a651;"<?php endif; ?>></i>
        Delivered



    </div>

    <hr />

    <div class="row">
        <div class="col-md-2">
            <a href="" style="text-align: left;"
               class="btn btn-primary btn-icon icon-left btn-block ">
                Overview
                <i class="entypo-info"></i>
            </a>

            <a href="" style="text-align: left;"
               class="btn btn-default btn-icon icon-left btn-block">
                Invoice
                <i class="entypo-docs"></i>
            </a>


        </div>
        <div class="col-md-10">
            <div class="panel panel-default" data-collapsed="0">
                <div class="panel-body">
                    <table class="table table-bordered table-responsive">
                        <thead>
                        <tr>
                            <th width="35%">Product</th>
                            <th width="10%;">Variant</th>
                            <th width="10%;">Price</th>
                            <th width="9%;">Quantity</th>
                            <th width="8%;">Discount %</th>
                            <th width="12%;">Total</th>
                            <th>Subtotal</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                            $products = json_decode($sale->products);
                        ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $product = \App\Product::find($prod->id);
                                $variant = \App\Variant::find($prod->variant_id);
                            ?>
                        <tr>
                            <td>
                                <?php echo e($product ->name); ?>

                            </td>
                            <td>
                                <?php echo e($variant->name); ?>

                            </td>
                            <td>
                                <?php echo e(format_price($product->price)); ?>

                            </td>
                            <td>
                                <?php echo e($prod->qty); ?>

                            </td>
                            <td>
                                <?php echo e($prod->discount); ?>

                            </td>
                            <td>
                                <?php echo e(format_price($prod->total_amount)); ?>

                            </td>

                            <td>
                                <?php echo e(format_price($prod->total_amount - $prod->discount_amount)); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="5"></td>

                            <td><b>Total</b></td>
                            <td><b><?php echo e(format_price($sale->subtotal_amount)); ?></b></td>
                        </tr>
                        <tr>
                            <td colspan="5"></td>

                            <td><b>Discount</b></td>
                            <td><b>- <?php echo e(format_price($sale->discount_amount)); ?></b></td>
                        </tr>
                        <tr>
                            <td colspan="5"></td>

                            <td><b>Shipping</b></td>
                            <td><b><?php echo e(format_price($sale->shipping_amount)); ?></b></td>
                        </tr>
                        <tr>
                            <td colspan="5"></td>

                            <td><b>Grand Total</b></td>
                            <td><b><?php echo e(format_price($sale->total_amount)); ?></b></td>
                        </tr>
                        </tbody>
                    </table>


                    <br>
                    <p>
                        <a href="#"
                           class="btn btn-success btn-icon icon-left btn-sm">
                            Confirm Order
                            <i class="entypo-check"></i>
                        </a>
                        <a href="#"
                           class="btn btn-danger btn-icon icon-left btn-sm">
                            Cancel Order
                            <i class="entypo-cancel"></i>
                        </a>
                    </p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>