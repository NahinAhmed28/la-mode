<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary" data-collapsed="0">
            <div class="panel-heading">
                <div class="panel-title" >
                    <i class="entypo-plus-circled"></i>
                    Add Customer
                </div>
            </div>
            <div class="panel-body">

                <?php echo Form::open(array('method'=>'POST', 'class'=> 'form-horizontal  validate')); ?>



                    <div class="form-group">
                        <label class="col-sm-3 control-label">Name</label>
                        <div class="col-sm-9">
                                <?php echo Form::text('name', null, array( 'id' => 'name', 'placeholder' => 'Name','class' => 'form-control', 'required' => 'required')); ?>

                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3 control-label">Phone</label>
                        <div class="col-sm-9">
                            <?php echo Form::text('phone', null, array('id' => 'phone','placeholder' => 'phone', 'class' => 'form-control', 'required' => 'required')); ?>

                        </div>
                    </div>



                    <div class="form-group">
                        <label class="col-sm-3 control-label">Email</label>
                        <div class="col-sm-9">
                            <?php echo Form::text('email', null, array('id' => 'email','placeholder' => 'Email','class' => 'form-control')); ?>

                        </div>
                    </div>

                    <?php
                        $val= [
                            'Male' => 'Male',
                            'Female' => 'Female'];
                    ?>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Gender</label>
                        <div class="col-sm-9">
                            <?php echo Form::select('gender', $val, null, array('id' => 'gender','class' => 'form-control')); ?>

                        </div>
                    </div>

                <div class="form-group">
                    <div class="col-sm-offset-3 col-sm-5">
                        <button type="submit" class="btn btn-info btn-submit">

                                <?php echo e('Create'); ?>

                        </button>
                    </div>
                </div>
                <?php echo Form::close(); ?>

            </div>

        </div>
    </div>
</div>

<script type="text/javascript">



    $.ajaxSetup({

        headers: {

            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'

        }

    });



    $(".btn-submit").click(function(e){

        e.preventDefault();



        var name = $('#name').val();
        var phone = $('#phone').val();
        var email = $('#email').val();
        var gender = $('#gender').val();

        var url = '<?php echo e(route("sales.customer_store")); ?>';



        $.ajax({

            type:'POST',

            url: url,

            data:{name:name, phone:phone, email:email, gender: gender},

            success:function(response){

                window.parent.jQuery('#customer_id').val(response.customer_id);
                window.parent.jQuery('#customer_name').val(response.name);
                window.parent.jQuery('#customer_phone').val(response.phone);
                window.parent.jQuery('#address1').val(response.address1);
                window.parent.jQuery('#address2').val(response.address2);
                window.parent.jQuery('#city').val(response.city);
                window.parent.jQuery('#zipcode').val(response.zipcode);



                $('#modal_ajax').modal('toggle');

            }

        });



    });

